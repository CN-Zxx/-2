Tested on
	Windows 7, ..., Windows 10
Install
	.NET Framework 4.7.2